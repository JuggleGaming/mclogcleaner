<?php

return [
    // Config values for LogCleaner
];

## McLogCleaner

This plugin will delete all .log.gz files inside the logs folder.

To use this plugin just add "mclogcleaner" as a feature to the egg you want to use this plugin with.
